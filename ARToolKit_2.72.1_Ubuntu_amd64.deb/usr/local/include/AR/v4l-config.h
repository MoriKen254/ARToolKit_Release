#define HAVE_CAMV4L 1
